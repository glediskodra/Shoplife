document.write(

  `
    <header class="header min-vh-10" role="banner">
      <div class="header-container intro-header">
        <img src="/assets/img/intro-header-mobile.png" class="card-img d-md-none mobile" alt="...">
        <img src="/assets/img/intro-header.jpg" class="card-img d-none d-md-block desktop" alt="...">
      </div>
    </header>


    <div class="card mb-3">
      <div class="row no-gutters">

        <div class="col-lg-6 col-md-8 col-12 offset-lg-1 ">
          <div class="card-body intro-body">
            <h5 class="card-title home">
            </h5>
            <p class="card-text page-text"></p>
            <p class="card-text-2 page-text"></p>

            <div class="btn-holder">
              <div class="input-group mb-3">
                <div class="button-wrap view-pageone-btn">
                  <button type="button" class="btn btn-secondary purple-btn intro_btn">

                  </button>
                  <div class="input-group-append">
                    <span class="input-group-text" id="basic-addon2">&gt;</span>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>

      </div>
    </div>`
);