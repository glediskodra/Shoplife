document.write(
  `
  <div class="row">
    <div class="col-lg-9 col-12 offset-lg-1">
      <div class="page-content-element animated fadeInRight">
        <div class="page-intro animated fadeInRight fadeIn">
          <h5 class="title"></h5>
          <p class="sub-title purple-text"> </p>
        </div>
        <div class="detail animated  fadeIn">
          <ul class="list-group questions-wrap">
          </ul>
          <div class="btn-holder d-flex">
            <div class="input-group mb-3">
              <div class="button-wrap back-to_page1-btn">
                <div class="input-group-append">
                  <span class="input-group-text" id="basic-addon2">&lt;</span>
                </div>
                <button type="button"  class="btn btn-secondary purple-btn left back">
                </button>
              </div>
            </div>
            <div class="input-group mb-3">
              <div class="button-wrap view-page1-c-btn disabled">
                <button type="button" class="btn btn-secondary purple-btn next">
                </button>
                <div class="input-group-append">
                  <span class="input-group-text" id="basic-addon2">&gt;</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  `
);