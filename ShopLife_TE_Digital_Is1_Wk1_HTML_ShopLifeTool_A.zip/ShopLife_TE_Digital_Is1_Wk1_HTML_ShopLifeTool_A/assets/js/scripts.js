/*!
 * The Crocodile
 * Award winning B2B marketing agency
 * https://thecroc.com
 * @author Benji Huggins
 * @version 1.0.5
 * Copyright 2019. MIT licensed.
 */
/*!
 * The Crocodile
 * Award winning B2B marketing agency
 * https://thecroc.com
 * @author Benji Huggins
 * @version 1.0.5
 * Copyright 2019. MIT licensed.
 */


(function($) {

  'use strict';

  $(function() {

    $('#reload').click(function() {
      window.location.reload();
    });

    var item = $('item-yes-btn');
    var totalCounter = 0;
    var firstPageCounter = 0;
    var secondPageCounter = 0;
    var thirdPageCounter = 0;
    var results = null;

    function hideAllPages() {
      $('.intro-page').hide();
      $('.page-1').hide();
      $('.page-1b').hide();
      $('.page-1c').hide();
      $('.page-1d').hide();
      $('.page-2').hide();
      $('.page-2b').hide();
      $('.page-2c').hide();
      $('.page-2d').hide();
      $('.page-3').hide();
      $('.page-3b').hide();
      $('.page-3c').hide();
    }

    //Logic for the counter
    function totalCounterValue() {
      var item = $('item-yes-btn');
      $(document).on('click', '.item-yes-btn', function() {
        if (!$(this).hasClass('added')) {
          while (totalCounter < 20) {
            totalCounter++;
            break;
          }
        }
        $(this).addClass('chosen');
        $(this).addClass('added');
        $(this).parent().find('.item-no-btn').removeClass('chosen');
      });
      $('.item-no-btn').click(function() {
        $(this).addClass('chosen');
        $(this).parent().find('.item-yes-btn').removeClass('chosen');
      });
    }

    function PageOneCounter() {
      $(document).on('click', '.group-1-no-btn', function() {
        if (!$(this).hasClass('added')) {
          while (firstPageCounter < 8) {
            firstPageCounter++;
            break;
          }
        }
        $(this).addClass('added');
      });
    }

    function PageTwoCounter() {
      $(document).on('click', '.group-2-no-btn', function() {
        if (!$(this).hasClass('added')) {
          while (secondPageCounter < 7) {
            secondPageCounter++;
            break;
          }
        }
        $(this).addClass('added');
      });
    }

    function PageThreeCounter() {
      $(document).on('click', '.group-3-no-btn', function() {
        if (!$(this).hasClass('added')) {
          while (thirdPageCounter < 5) {
            thirdPageCounter++;
            break;
          }
        }
        $(this).addClass('added');
      });
    }

    function sortList() {
      var firstPage = $('.page1-recommended');
      var secondPage = $('.page2-recommended');
      var thirdPage = $('.page3-recommended');
      var fourthPage = $('.page4-recommended');
      var fifthPage = $('.page5-recommended');
      $('.recommended-pages-holder').show();





      if (firstPageCounter > secondPageCounter && firstPageCounter > thirdPageCounter) {
        firstPage.show();
        secondPage.hide();
        thirdPage.hide();
        fourthPage.hide();
        fifthPage.hide();
      } else if (secondPageCounter > firstPageCounter && secondPageCounter > thirdPageCounter) {
        firstPage.hide();
        secondPage.hide();
        thirdPage.hide();
        fourthPage.show();
        fifthPage.hide();
      } else if (thirdPageCounter > secondPageCounter && thirdPageCounter > firstPageCounter) {
        firstPage.hide();
        secondPage.hide();
        thirdPage.hide();
        fourthPage.hide();
        fifthPage.show();
      } else if (firstPageCounter === secondPageCounter) {
        firstPage.show();
        secondPage.hide();
        thirdPage.hide();
        fourthPage.hide();
        fifthPage.hide();
      } else if (firstPageCounter === thirdPageCounter) {
        firstPage.hide();
        secondPage.hide();
        thirdPage.show();
        fourthPage.hide();
        fifthPage.hide();
      } else if (secondPageCounter === thirdPageCounter) {
        firstPage.hide();
        secondPage.show();
        thirdPage.hide();
        fourthPage.hide();
        fifthPage.hide();
      } else if (firstPageCounter === 0 && secondPageCounter === 0 && thirdPageCounter === 0 || firstPageCounter === 0 && secondPageCounter === 0 && thirdPageCounter === 0) {
        firstPage.show();
        secondPage.hide();
        thirdPage.hide();
        fourthPage.hide();
        fifthPage.hide();
      } else {
        firstPage.show();
        secondPage.hide();
        thirdPage.hide();
        fourthPage.hide();
        fifthPage.hide();
      }


      if (totalCounter <= 9) {
        $('.card-title').hide();
        $('.overall-text-2').hide();
        $('.card-title-2').show();
        $('.overall-text').show();

        $('.below10').show();
        $('.above10').hide();
        $('.equal20').hide();

      } else if (totalCounter >= 10 && totalCounter < 20) {
        $('.overall-text').show();
        $('.overall-text-2').hide();
        $('.card-title-2').hide();
        $('.card-title').show();

        $('.below10').hide();
        $('.above10').show();
        $('.equal20').hide();
      } else if (totalCounter === 20) {
        $('.overall-text').hide();
        $('.card-title-2').hide();
        $('.card-title').show();
        $('.overall-text-2').show();

        $('.below10').hide();
        $('.above10').hide();
        $('.equal20').show();
      }
    }

    //Logic from intro to get to Page1
    function introPage() {
      hideAllPages();
      $('.intro-page').show();

    }

    hideAllPages();
    //hideAllRecommendedPages();


    $('.back-to_intro-btn').click(function() {
      hideAllPages();
      $('.intro-page').show();
    });

    $('.back-to_page1-btn').click(function() {
      hideAllPages();
      $('.page-1').show();
    });

    $('.back-to_page1-b-btn').click(function() {
      hideAllPages();
      $('.page-1b').show();
    });


    $('.back-to_page1-c-btn').click(function() {
      hideAllPages();
      $('.page-1c').show();
    });

    $('.back-to_page1-d-btn').click(function() {
      hideAllPages();
      $('.page-1d').show();
    });

    $('.back-to_page-2-btn').click(function() {
      hideAllPages();
      $('.page-2').show();
    });

    $('.back-to_page-2b-btn').click(function() {
      hideAllPages();
      $('.page-2b').show();
    });

    $('.back-to_page-2c-btn').click(function() {
      hideAllPages();
      $('.page-2c').show();
    });

    $('.back-to_page-2d-btn').click(function() {
      hideAllPages();
      $('.page-2d').show();
    });

    $('.back-to_page-3-btn').click(function() {
      hideAllPages();
      $('.page-3').show();
    });

    $('.back-to_page-3b-btn').click(function() {
      hideAllPages();
      $('.page-3b').show();
    });

    $('.back-to_page-3c-btn').click(function() {
      hideAllPages();
      $('.page-3c').show();
    });


    //Logic for retrieving data from the json files
    function getData(data) {
      $.get(data, function(response) {

        var li = '<li class="list-group-item">';
        results = response;

        $.each(results, function(key, val) {
          $('.' + val.category + ' .title').text(val.heading);
          $('.' + val.category + ' .catch-phrase').text(val.heading);
          $('.' + val.category + ' .sub-title').text(val.sub_title);

          $('.' + val.category + ' .btn-holder .back').text(val.back_text);
          $('.' + val.category + ' .btn-holder .next').text(val.next_text);

          //##########################
          //  INTRO PAGE
          //############################
          if (val.category === 'intro-page') {
            $('.intro-page .home').prepend(val.sub_title);
            $('.intro-page .card-title .sub_title').append(val.sub_title);
            $('.intro-page .card-text').append(val.text);
            $('.intro-page .card-text-2').append(val.text_2);
            $('.intro-page .intro_btn').append(val.next_text);

          } else {
            $.each(val.questions, function(key, quest) {
              $('.' + val.category + ' .list-group').append(
                li +
                '<p class="question">' + quest.question + '</p>' +
                '<div class="item-btn-holder">' +
                '<button type="button" class="btn btn-secondary ' + val.group + '-yes-btn item-yes-btn"> ' + val.yes_btn_text + '</button>' +
                '<button type="button" class="btn btn-secondary ' + val.group + '-no-btn item-no-btn chosen">' + val.no_btn_text + '</button>' +
                '</div>' +
                '</li>'
              );
            });
          }

          $('.list-group .list-group-item:nth-child(n+3)').addClass('not-include');


          //####################################################
          //  RESULT PAGES
          //######################################################
          if (val.category === 'result-page') {

            $('.header').hide();
            $('.recommended-pages-holder').hide();

            //########### populate the results items#######
            $('.card-title').append(val.heading);
            $('.card-title-2').append(val.heading_2);
            $('.no-quest').append(val.extra_quest);
            $('.see-result').append(val.sub_heading);
            $('.overall-text').append(val.overall_text);
            $('.overall-text-2').append(val.overall_text_2);
            $('.recommend_btn_text').append(val.recommend_btn_text);

            $('.slider1-title').text(val.slider1_title);
            $('.below10').text(val.slider1_low_score);
            $('.above10').text(val.slider1_mid_score);
            $('.equal20').text(val.slider1_high_score);

            $('.slider2-title').text(val.slider2_title);
            //#######################################################
            $('.slider3-subtext').html(val.slider3_subtext);
            $('.slider3-reloadtext').html(val.slider3_reloadtext);

            $('.recommend_btn').click(function() {
              $('.result-content').hide();
              $('body').addClass('no-dots-bg');
              sortList();
            });

            //####################################################
            //  PAGE1  RESULT PAGE
            //######################################################

            $('.page1-recommended .recommeded-back-to-result-btn').click(function() {
              $('body').removeClass('no-dots-bg');
              $('.recommended-pages-holder').hide();
              $('.result-content').show();
            });

            $('.page1-recommended .page1-view-bucket2-next-btn').click(function() {
              $('.bucket1-recommendation').hide();
              $('.bucket2-recommendation').show();
            });

            $('.page1-recommended .recommeded-back-to-bucket1-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket1-recommendation').show();
            });

            $('.page1-recommended .page1-view-bucket3-next-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket3-recommendation').show();
            });


            //####################################################
            //  PAGE2  RESULT PAGE
            //######################################################

            $('.page2-recommended .recommeded-back-to-result-btn').click(function() {
              $('body').removeClass('no-dots-bg');
              $('.recommended-pages-holder').hide();
              $('.result-content').show();
            });

            $('.page2-recommended .page1-view-bucket2-next-btn').click(function() {
              $('.bucket1-recommendation').hide();
              $('.bucket2-recommendation').show();
            });

            $('.page2-recommended .recommeded-back-to-bucket1-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket1-recommendation').show();
            });

            $('.page2-recommended .page1-view-bucket3-next-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket3-recommendation').show();
            });



            //####################################################
            //  PAGE3  RESULT PAGE
            //######################################################

            $('.page3-recommended .recommeded-back-to-result-btn').click(function() {
              $('body').removeClass('no-dots-bg');
              $('.recommended-pages-holder').hide();
              $('.result-content').show();
            });

            $('.page3-recommended .page1-view-bucket2-next-btn').click(function() {
              $('.bucket1-recommendation').hide();
              $('.bucket2-recommendation').show();
            });

            $('.page3-recommended .recommeded-back-to-bucket1-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket1-recommendation').show();
            });

            $('.page3-recommended .page1-view-bucket3-next-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket3-recommendation').show();
            });

            //####################################################
            //  PAGE4  RESULT PAGE
            //######################################################

            $('.page4-recommended .recommeded-back-to-result-btn').click(function() {
              $('body').removeClass('no-dots-bg');
              $('.recommended-pages-holder').hide();
              $('.result-content').show();
            });

            $('.page4-recommended .page1-view-bucket2-next-btn').click(function() {
              $('.bucket1-recommendation').hide();
              $('.bucket2-recommendation').show();
            });

            $('.page4-recommended .recommeded-back-to-bucket1-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket1-recommendation').show();
            });

            $('.page4-recommended .page1-view-bucket3-next-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket3-recommendation').show();
            });

            //####################################################
            //  PAGE5  RESULT PAGE
            //######################################################

            $('.page5-recommended .recommeded-back-to-result-btn').click(function() {
              $('body').removeClass('no-dots-bg');
              $('.recommended-pages-holder').hide();
              $('.result-content').show();
            });

            $('.page5-recommended .page1-view-bucket2-next-btn').click(function() {
              $('.bucket1-recommendation').hide();
              $('.bucket2-recommendation').show();
            });

            $('.page5-recommended .recommeded-back-to-bucket1-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket1-recommendation').show();
            });

            $('.page5-recommended .page1-view-bucket3-next-btn').click(function() {
              $('.bucket2-recommendation').hide();
              $('.bucket3-recommendation').show();
            });





          }

          totalCounterValue();
          PageOneCounter();
          PageTwoCounter();
          PageThreeCounter();
          results = null;
        });

      });

    }



    //Logic for the Page1
    function viewPageOne() {
      $('.view-pageone-btn').click(function() {
        getData('./assets/js/data/page1/page1.json');
        hideAllPages();
        $('.page-1').show();
      });
    }

    function viewPageOneB() {
      $('.view-page1-b-btn').click(function() {
        getData('./assets/js/data/page1/page1_b.json');
        hideAllPages();
        $('.page-1b').show();
      });
    }

    function viewPageOneC() {
      $('.view-page1-c-btn').click(function() {
        getData('./assets/js/data/page1/page1_c.json');
        hideAllPages();
        $('.page-1c').show();
      });
    }

    function viewPageOneD() {
      $('.view-page1-d-btn').click(function() {
        getData('./assets/js/data/page1/page1_d.json');
        hideAllPages();
        $('.page-1d').show();
      });
    }

    function viewPageTwo() {
      $('.view-page2-btn').click(function() {
        getData('./assets/js/data/page2/page2.json');
        hideAllPages();
        $('.page-2').show();
      });
    }

    function viewPageTwoB() {
      $('.view-page2-b-btn').click(function() {
        getData('./assets/js/data/page2/page2_b.json');
        hideAllPages();
        $('.page-2b').show();
      });
    }

    function viewPageTwoC() {
      $('.view-page2-c-btn').click(function() {
        getData('./assets/js/data/page2/page2_c.json');
        hideAllPages();
        $('.page-2c').show();
      });
    }

    function viewPageTwoD() {
      $('.view-page2-d-btn').click(function() {
        getData('./assets/js/data/page2/page2_d.json');
        hideAllPages();
        $('.page-2d').show();
      });
    }

    function viewPageThree() {
      $('.view-page-3-btn').click(function() {
        getData('./assets/js/data/page3/page3.json');
        hideAllPages();
        $('.page-3').show();
      });
    }

    function viewPageThreeB() {
      $('.view-page3-b-btn').click(function() {
        getData('./assets/js/data/page3/page3_b.json');
        hideAllPages();
        $('.page-3b').show();
      });
    }

    function viewPageThreeC() {
      $('.view-page3-c-btn').click(function() {
        getData('./assets/js/data/page3/page3_c.json');
        hideAllPages();
        $('.page-3c').show();
      });
    }


    //Logic for the Result page
    function viewResultPage() {
      $('.view-result-btn').click(function() {
        getData('./assets/js/data/result-data.json');
        hideAllPages();
        $('.result-page').show();
        $('.result_value').append(totalCounter); // displays the total YES clicked.

        sortList();

      });

    }




    // Page 1- 1d
    introPage();
    viewPageOne();
    viewPageOneB();
    viewPageOneC();
    viewPageOneD();

    // Pages 2- 2d
    viewPageTwo();
    viewPageTwoB();
    viewPageTwoC();
    viewPageTwoD();

    // Pages 3- 3c
    viewPageThree();
    viewPageThreeB();
    viewPageThreeC();

    // Result Page
    viewResultPage();



    totalCounterValue();

    getData('./assets/js/data/intro.json'); //Get the intro page data on page load


    // Second active class for buttons & validate next button active state
    $(document).on('click', '.questions-wrap .item-btn-holder .btn', function() {

      $(this).parent().find('.btn').removeClass('active-true');
      $(this).addClass('active-true');
      $(this).parent().parent().addClass('completed');

      // if ($(this).closest('.detail').find('.list-group-item:not(.completed)').length === 0) {

      //   $(this).closest('.detail').find('.button-wrap').removeClass('disabled');
      // }
      if ($(this).parent().parent().parent().parent().find('.list-group-item.completed').length === $(this).parent().parent().parent().parent().find('.list-group-item:not(.not-include)').length) {

        //return true
        $(this).parent().parent().parent().parent().find('.button-wrap').removeClass('disabled');
      }

    });

    //add swipe functionality to results sliders
    $(".carousel").swipe({
      swipe: function(event, direction, distance, duration, fingerCount, fingerData) {

        if (direction === 'left') $(this).carousel('next');
        if (direction === 'right') $(this).carousel('prev');

      },
      allowPageScroll: "vertical"
    });

  });
})(jQuery, window, document);